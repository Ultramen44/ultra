from kyt import *
import subprocess
import os

@bot.on(events.NewMessage(pattern=r"(?:.menu|/menu)$"))
@bot.on(events.CallbackQuery(data=b'menu'))
async def menu(event):
    # --- Susunan Tombol ---
    inline = [
        [Button.inline(" SSH OVPN MANAGER ","ssh")],
        [Button.inline(" VMESS MANAGER ","vmess"), Button.inline(" VLESS MANAGER ","vless")],
        [Button.inline(" TROJAN MANAGER ","trojan"), Button.inline(" SHDWSK MANAGER ","shadowsocks")],
        [Button.inline(" CHECK VPS INFO ","info"), Button.inline(" OTHER SETTING ","setting")],
        [Button.inline(" ‹ Back Menu › ","start")]
    ]
    
    sender = await event.get_sender()
    val = valid(str(sender.id))
    
    # --- Validasi Admin ---
    if val == "false":
        try:
            await event.answer("Akses Ditolak! Anda bukan Admin.", alert=True)
        except:
            await event.reply("Akses Ditolak!")
        return 
            
    elif val == "true":
        try:
            # 1. Menghitung User SSH (UID >= 1000, exclude nobody)
            ssh = subprocess.check_output("awk -F: '$3 >= 1000 && $1 != \"nobody\" {print $1}' /etc/passwd | wc -l", shell=True).decode("ascii").strip()
            
            # 2. Menghitung Akun XRAY (VMESS, VLESS, TROJAN) langsung dari config.json
            # Pembagi $((vmc / 2)) digunakan jika config mencatat 2 baris (TLS & NTLS) per user
            vms = subprocess.check_output('vmc=$(grep -c -E "^### " "/etc/xray/config.json"); echo $((vmc / 2))', shell=True).decode("ascii").strip()
            vls = subprocess.check_output('vlx=$(grep -c -E "^#& " "/etc/xray/config.json"); echo $((vlx / 2))', shell=True).decode("ascii").strip()
            trj = subprocess.check_output('trx=$(grep -c -E "^#! " "/etc/xray/config.json"); echo $((trx / 2))', shell=True).decode("ascii").strip()
        except Exception as e:
            ssh = vms = vls = trj = "0"
        
        # --- Mengambil Informasi VPS ---
        try:
            cmd_os = "cat /etc/os-release | grep -w PRETTY_NAME | cut -d= -f2 | sed 's/\"//g'"
            namaos = subprocess.check_output(cmd_os, shell=True).decode("ascii").strip()
        except:
            namaos = "Unknown OS"
        
        try:
            ipsaya = subprocess.check_output("curl -s ipv4.icanhazip.com", shell=True, timeout=5).decode("ascii").strip()
        except:
            ipsaya = "Tidak Terdeteksi"
            
        if os.path.exists("/etc/xray/city"):
            with open("/etc/xray/city", "r") as f:
                city = f.read().strip()
        else:
            city = "International"

        # --- Tampilan Pesan ---
        msg = f"""
━━━━━━━━━━━━━━━━━━━━━━━ 
** 🔹 PANEL MENU 🔹 **
━━━━━━━━━━━━━━━━━━━━━━━ 
**» OS      :** `{namaos}`
**» CITY    :** `{city}`
**» DOMAIN  :** `{DOMAIN}`
**» IP VPS  :** `{ipsaya}`
━━━━━━━━━━━━━━━━━━━━━━━ 
**» Total Active Account:**
**» 🚀 SSH OVPN      :** `{ssh}` __user__
**» 🎭 XRAY VMESS    :** `{vms}` __user__
**» 🗼 XRAY VLESS    :** `{vls}` __user__
**» 🎯 XRAY TROJAN   :** `{trj}` __user__
━━━━━━━━━━━━━━━━━━━━━━━ 
"""
        try:
            await event.edit(msg, buttons=inline)
        except:
            await event.reply(msg, buttons=inline)