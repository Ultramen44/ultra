from kyt import *
import subprocess
import os
from telethon import events
from telethon.tl.custom import Button

@bot.on(events.NewMessage(pattern=r"(?:.menu|/menu)$"))
@bot.on(events.CallbackQuery(data=b'menu'))
async def menu(event):
    # --- Susunan Tombol (Gaya Lama) ---
    inline = [
        [Button.inline(" SSH OVPN MANAGER ","ssh")],
        [Button.inline(" VMESS MANAGER ","vmess"), Button.inline(" VLESS MANAGER ","vless")],
        [Button.inline(" TROJAN MANAGER ","trojan"), Button.inline(" SHDWSK MANAGER ","shadowsocks")],
        [Button.inline(" CHECK VPS INFO ","info"), Button.inline(" OTHER SETTING ","setting")],
        [Button.inline(" ‹ Back Menu › ","start")]
    ]
    
    sender = await event.get_sender()
    val = valid(str(sender.id))
    
    if val == "false":
        try:
            await event.answer("Akses Ditolak! Anda bukan Admin.", alert=True)
        except:
            await event.reply("Akses Ditolak!")
            
    elif val == "true":
        # Memberikan feedback loading agar bot terasa responsif
        if isinstance(event, events.CallbackQuery.Event):
            await event.answer("Menghitung data...", alert=False)

        # --- Logika Perhitungan Akun (Diadaptasi dari Script Baru) ---
        try:
            # Menghitung User SSH (UID >= 1000)
            ssh = subprocess.check_output("awk -F: '$3 >= 1000 && $1 != \"nobody\" {print $1}' /etc/passwd | wc -l", shell=True).decode("ascii").strip()
            
            # Menghitung Akun XRAY dari config.json dengan pembagian 2
            vms = subprocess.check_output('vmc=$(grep -c -E "^### " "/etc/xray/config.json"); echo $((vmc / 2))', shell=True).decode("ascii").strip()
            vls = subprocess.check_output('vlx=$(grep -c -E "^#& " "/etc/xray/config.json"); echo $((vlx / 2))', shell=True).decode("ascii").strip()
            trj = subprocess.check_output('trx=$(grep -c -E "^#! " "/etc/xray/config.json"); echo $((trx / 2))', shell=True).decode("ascii").strip()
            
            # Informasi Sistem
            namaos = subprocess.check_output("cat /etc/os-release | grep -w PRETTY_NAME | cut -d= -f2 | sed 's/\"//g'", shell=True).decode("ascii").strip()
            ipsaya = subprocess.check_output("curl -s ipv4.icanhazip.com", shell=True, timeout=5).decode("ascii").strip()
            
            if os.path.exists("/etc/xray/city"):
                city = subprocess.check_output("cat /etc/xray/city", shell=True).decode("ascii").strip()
            else:
                city = "International"
        
        except Exception:
            # Jika file config.json tidak ditemukan atau error lainnya
            ssh = vms = vls = trj = "0"
            namaos = "Linux VPS"
            ipsaya = "127.0.0.1"
            city = "Unknown"

        # --- Tampilan Pesan (Gabungan Estetika Lama & Baru) ---
        msg = f"""
━━━━━━━━━━━━━━━━━━━━━━━ 
** 🔹 PANEL MENU 🔹 **
━━━━━━━━━━━━━━━━━━━━━━━ 
**» OS      :** `{namaos}`
**» CITY    :** `{city}`
**» DOMAIN  :** `{DOMAIN}`
**» IP VPS  :** `{ipsaya}`
━━━━━━━━━━━━━━━━━━━━━━━ 
**» Total Account Created:**
**» 🚀 SSH OVPN      :** `{ssh}` __user__
**» 🎭 XRAY VMESS    :** `{vms}` __user__
**» 🗼 XRAY VLESS    :** `{vls}` __user__
**» 🎯 XRAY TROJAN   :** `{trj}` __user__
━━━━━━━━━━━━━━━━━━━━━━━ 
"""
        # --- Eksekusi Pengiriman ---
        try:
            await event.edit(msg, buttons=inline)
        except:
            await event.reply(msg, buttons=inline)