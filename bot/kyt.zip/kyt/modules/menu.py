from kyt import *
import subprocess
import os

@bot.on(events.NewMessage(pattern=r"(?:.menu|/menu)$"))
@bot.on(events.CallbackQuery(data=b'menu'))
async def menu(event):
    # --- Susunan Tombol ---
    inline = [
        [Button.inline(" SSH OVPN MANAGER ","ssh")],
        [Button.inline(" VMESS MANAGER ","vmess"), Button.inline(" VLESS MANAGER ","vless")],
        [Button.inline(" TROJAN MANAGER ","trojan"), Button.inline(" SHDWSK MANAGER ","shadowsocks")],
        [Button.inline(" CHECK VPS INFO ","info"), Button.inline(" OTHER SETTING ","setting")],
        [Button.inline(" ‹ Back Menu › ","start")]
    ]
    
    sender = await event.get_sender()
    val = valid(str(sender.id))
    
    if val == "false":
        try:
            await event.answer("Akses Ditolak! Anda bukan Admin.", alert=True)
        except:
            await event.reply("Akses Ditolak!")
            
    elif val == "true":
        # 1. Menghitung User SSH (Hanya user manual dengan UID >= 1000)
        # Menghindari user sistem seperti 'nobody', 'messagebus', dll.
        cmd_ssh = "awk -F: '$3 >= 1000 && $1 != \"nobody\" {print $1}' /etc/passwd | wc -l"
        ssh = subprocess.check_output(cmd_ssh, shell=True).decode("ascii").strip()
        
        # 2. Menghitung Akun XRAY (Vmess, Vless, Trojan)
        # Menggunakan 'grep -c' agar lebih cepat dan aman dari error 'file not found'
        def count_xray(path):
            if os.path.exists(path):
                cmd = f"grep -c '###' {path}"
                return subprocess.check_output(cmd, shell=True).decode("ascii").strip()
            return "0"

        vms = count_xray("/etc/vmess/.vmess.db")
        vls = count_xray("/etc/vless/.vless.db")
        trj = count_xray("/etc/trojan/.trojan.db")
        
        # 3. Mengambil Informasi VPS
        # OS Name
        cmd_os = "cat /etc/os-release | grep -w PRETTY_NAME | cut -d= -f2 | sed 's/\"//g'"
        namaos = subprocess.check_output(cmd_os, shell=True).decode("ascii").strip()
        
        # IP VPS
        try:
            ipsaya = subprocess.check_output("curl -s ipv4.icanhazip.com", shell=True, timeout=5).decode("ascii").strip()
        except:
            ipsaya = "Tidak Terdeteksi"
            
        # City
        if os.path.exists("/etc/xray/city"):
            city = subprocess.check_output("cat /etc/xray/city", shell=True).decode("ascii").strip()
        else:
            city = "International"

        # --- Tampilan Pesan ---
        msg = f"""
━━━━━━━━━━━━━━━━━━━━━━━ 
** 🔹 PANEL MENU 🔹 **
━━━━━━━━━━━━━━━━━━━━━━━ 
**» OS      :** `{namaos}`
**» CITY    :** `{city}`
**» DOMAIN  :** `{DOMAIN}`
**» IP VPS  :** `{ipsaya}`
━━━━━━━━━━━━━━━━━━━━━━━ 
**» Total Account Created:**
**» 🚀 SSH OVPN      :** `{ssh}` __user__
**» 🎭 XRAY VMESS    :** `{vms}` __user__
**» 🗼 XRAY VLESS    :** `{vls}` __user__
**» 🎯 XRAY TROJAN   :** `{trj}` __user__
━━━━━━━━━━━━━━━━━━━━━━━ 
"""
        # --- Eksekusi Pengiriman Pesan ---
        try:
            # Mencoba mengedit pesan jika dipicu dari tombol (callback)
            await event.edit(msg, buttons=inline)
        except:
            # Jika dipicu dari command text (.menu), kirim pesan baru
            await event.reply(msg, buttons=inline)