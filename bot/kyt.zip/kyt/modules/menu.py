from kyt import *
import subprocess
import os

@bot.on(events.NewMessage(pattern=r"(?:.menu|/menu)$"))
@bot.on(events.CallbackQuery(data=b'menu'))
async def menu(event):
    # --- Susunan Tombol ---
    inline = [
        [Button.inline(" SSH OVPN MANAGER ","ssh")],
        [Button.inline(" VMESS MANAGER ","vmess"), Button.inline(" VLESS MANAGER ","vless")],
        [Button.inline(" TROJAN MANAGER ","trojan"), Button.inline(" SHDWSK MANAGER ","shadowsocks")],
        [Button.inline(" CHECK VPS INFO ","info"), Button.inline(" OTHER SETTING ","setting")],
        [Button.inline(" ‹ Back Menu › ","start")]
    ]
    
    sender = await event.get_sender()
    val = valid(str(sender.id))
    
    # --- Validasi Admin ---
    if val == "false":
        try:
            await event.answer("Akses Ditolak! Anda bukan Admin.", alert=True)
        except:
            await event.reply("Akses Ditolak!")
        return # Menghentikan eksekusi jika bukan admin
            
    elif val == "true":
        # 1. Menghitung User SSH (UID >= 1000, exclude nobody)
        cmd_ssh = "awk -F: '$3 >= 1000 && $1 != \"nobody\" {print $1}' /etc/passwd | wc -l"
        ssh = subprocess.check_output(cmd_ssh, shell=True).decode("ascii").strip()
        
        # 2. Fungsi & Eksekusi Menghitung Akun XRAY
        def count_xray(path):
            if os.path.exists(path):
                # Menghitung baris yang diawali '### '
                cmd = f"grep -c '^### ' {path} 2>/dev/null"
                try:
                    count = subprocess.check_output(cmd, shell=True).decode("ascii").strip()
                    return count if count else "0"
                except subprocess.CalledProcessError:
                    return "0"
            return "0"

        # Mengambil jumlah akun (Sudah diperbaiki dari script sebelumnya)
        vms = count_xray("/etc/vmess/.vmess.db")
        vls = count_xray("/etc/vless/.vless.db")
        trj = count_xray("/etc/trojan/.trojan.db")
        
        # 3. Mengambil Informasi VPS
        # OS Name
        try:
            cmd_os = "cat /etc/os-release | grep -w PRETTY_NAME | cut -d= -f2 | sed 's/\"//g'"
            namaos = subprocess.check_output(cmd_os, shell=True).decode("ascii").strip()
        except:
            namaos = "Unknown OS"
        
        # IP VPS
        try:
            ipsaya = subprocess.check_output("curl -s ipv4.icanhazip.com", shell=True, timeout=5).decode("ascii").strip()
        except:
            ipsaya = "Tidak Terdeteksi"
            
        # City Info
        if os.path.exists("/etc/xray/city"):
            with open("/etc/xray/city", "r") as f:
                city = f.read().strip()
        else:
            city = "International"

        # --- Tampilan Pesan ---
        msg = f"""
━━━━━━━━━━━━━━━━━━━━━━━ 
** 🔹 PANEL MENU 🔹 **
━━━━━━━━━━━━━━━━━━━━━━━ 
**» OS      :** `{namaos}`
**» CITY    :** `{city}`
**» DOMAIN  :** `{DOMAIN}`
**» IP VPS  :** `{ipsaya}`
━━━━━━━━━━━━━━━━━━━━━━━ 
**» Total Account Created:**
**» 🚀 SSH OVPN      :** `{ssh}` __user__
**» 🎭 XRAY VMESS    :** `{vms}` __user__
**» 🗼 XRAY VLESS    :** `{vls}` __user__
**» 🎯 XRAY TROJAN   :** `{trj}` __user__
━━━━━━━━━━━━━━━━━━━━━━━ 
"""
        # --- Eksekusi Pengiriman Pesan ---
        try:
            # Mencoba mengedit jika berasal dari callback button
            await event.edit(msg, buttons=inline)
        except:
            # Mengirim pesan baru jika diketik manual (.menu)
            await event.reply(msg, buttons=inline)