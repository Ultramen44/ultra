from kyt import *
import subprocess
import os
from datetime import datetime

# --- Fungsi Pembersih Akun Expired & Duplikat ---
def cleanup_and_count(path):
    if not os.path.exists(path):
        return "0"
    
    today = datetime.now().date()
    valid_lines = []
    seen_users = set()

    try:
        with open(path, "r") as f:
            lines = f.readlines()

        for line in lines:
            if line.startswith("###"):
                parts = line.split()
                # Asumsi format database: ### NamaUser YYYY-MM-DD
                if len(parts) >= 3:
                    user_name = parts[1]
                    exp_date_str = parts[2]
                    try:
                        exp_date = datetime.strptime(exp_date_str, "%Y-%m-%d").date()
                        # Hapus jika expired atau duplikat
                        if exp_date >= today and user_name not in seen_users:
                            valid_lines.append(line)
                            seen_users.add(user_name)
                    except ValueError:
                        # Jika format tanggal salah, tetap masukkan agar tidak hilang data penting
                        if user_name not in seen_users:
                            valid_lines.append(line)
                            seen_users.add(user_name)

        # Tulis ulang file database yang sudah bersih (Clean & Unique)
        with open(path, "w") as f:
            f.writelines(valid_lines)
            
        return str(len(valid_lines))
    except Exception as e:
        print(f"Error cleaning {path}: {e}")
        return "0"

@bot.on(events.NewMessage(pattern=r"(?:.menu|/menu)$"))
@bot.on(events.CallbackQuery(data=b'menu'))
async def menu(event):
    # --- Susunan Tombol ---
    inline = [
        [Button.inline(" SSH OVPN MANAGER ","ssh")],
        [Button.inline(" VMESS MANAGER ","vmess"), Button.inline(" VLESS MANAGER ","vless")],
        [Button.inline(" TROJAN MANAGER ","trojan"), Button.inline(" SHDWSK MANAGER ","shadowsocks")],
        [Button.inline(" CHECK VPS INFO ","info"), Button.inline(" OTHER SETTING ","setting")],
        [Button.inline(" ‹ Back Menu › ","start")]
    ]
    
    sender = await event.get_sender()
    val = valid(str(sender.id))
    
    # --- Validasi Admin ---
    if val == "false":
        try:
            await event.answer("Akses Ditolak! Anda bukan Admin.", alert=True)
        except:
            await event.reply("Akses Ditolak!")
        return 
            
    elif val == "true":
        # 1. Menjalankan Cleanup & Menghitung Akun XRAY secara Akurat
        vms = cleanup_and_count("/etc/vmess/.vmess.db")
        vls = cleanup_and_count("/etc/vless/.vless.db")
        trj = cleanup_and_count("/etc/trojan/.trojan.db")
        
        # 2. Menghitung User SSH (UID >= 1000, exclude nobody)
        try:
            cmd_ssh = "awk -F: '$3 >= 1000 && $1 != \"nobody\" {print $1}' /etc/passwd | wc -l"
            ssh = subprocess.check_output(cmd_ssh, shell=True).decode("ascii").strip()
        except:
            ssh = "0"
        
        # 3. Mengambil Informasi VPS
        try:
            cmd_os = "cat /etc/os-release | grep -w PRETTY_NAME | cut -d= -f2 | sed 's/\"//g'"
            namaos = subprocess.check_output(cmd_os, shell=True).decode("ascii").strip()
        except:
            namaos = "Unknown OS"
        
        try:
            ipsaya = subprocess.check_output("curl -s ipv4.icanhazip.com", shell=True, timeout=5).decode("ascii").strip()
        except:
            ipsaya = "Tidak Terdeteksi"
            
        if os.path.exists("/etc/xray/city"):
            with open("/etc/xray/city", "r") as f:
                city = f.read().strip()
        else:
            city = "International"

        # --- Tampilan Pesan ---
        msg = f"""
━━━━━━━━━━━━━━━━━━━━━━━ 
** 🔹 PANEL MENU 🔹 **
━━━━━━━━━━━━━━━━━━━━━━━ 
**» OS      :** `{namaos}`
**» CITY    :** `{city}`
**» DOMAIN  :** `{DOMAIN}`
**» IP VPS  :** `{ipsaya}`
━━━━━━━━━━━━━━━━━━━━━━━ 
**» Total Active Account:**
**» 🚀 SSH OVPN      :** `{ssh}` __user__
**» 🎭 XRAY VMESS    :** `{vms}` __user__
**» 🗼 XRAY VLESS    :** `{vls}` __user__
**» 🎯 XRAY TROJAN   :** `{trj}` __user__
━━━━━━━━━━━━━━━━━━━━━━━ 
"""
        try:
            await event.edit(msg, buttons=inline)
        except:
            await event.reply(msg, buttons=inline)