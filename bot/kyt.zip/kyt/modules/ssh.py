from kyt import *
import subprocess
import asyncio
import math
import time
import random
import requests
import datetime as DT
import os
from telethon.tl.custom import Button
from telethon import events
from telethon.errors import AlreadyInConversationError

# =================================================================
# FUNGSI PEMBANTU: AMBIL DATA & FORMAT PAGINATION
# =================================================================
def get_ssh_data():
    """Mengambil data raw dari script shell"""
    try:
        cmd = '/usr/bin/kyt/shell/bot/bot-member-ssh'
        if not os.path.exists(cmd):
            cmd = 'bot-member-ssh'
            
        raw_output = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT).decode("utf-8")
        data_list = [line for line in raw_output.splitlines() if line.strip()]
        return data_list
    except:
        return []

def render_page(data_list, page, item_per_page=10):
    total_items = len(data_list)
    total_pages = math.ceil(total_items / item_per_page)
    
    if page < 0: page = 0
    if total_pages > 0 and page >= total_pages: page = total_pages - 1
    if total_pages == 0: page = 0 
    
    start = page * item_per_page
    end = start + item_per_page
    sliced_data = data_list[start:end]
    
    msg = f"""
<b>━━━━━━━━━━━━━━━━━━━━━━━━━━━━</b>
<b>👑 LIST MEMBER SSH & OVPN</b>
<b>━━━━━━━━━━━━━━━━━━━━━━━━━━━━</b>
"""
    if not sliced_data:
        msg += "<i>Tidak ada user ssh active.</i>"
    else:
        for row in sliced_data:
            try:
                parts = row.split("|")
                if len(parts) >= 3:
                    user = parts[0]
                    exp = parts[1]
                    status = parts[2]
                    icon_stat = "🟢" if "UNLOCKED" in status else "🔴"
                    msg += f"""
<b>👤 User   :</b> <code>{user}</code>
<b>📅 Exp    :</b> <code>{exp}</code>
<b>💎 Status :</b> {icon_stat} <code>{status}</code>
<b>━━━━━━━━━━━━━━━━━━━━━━━━━━━━</b>
"""
                else: continue
            except: continue

    display_page = page + 1 if total_pages > 0 else 0
    msg += f"\n📊 <b>Total:</b> {total_items} Users | 📄 <b>Page:</b> {display_page}/{total_pages}"
    return msg, total_pages

# =================================================================
# 1. CREATE SSH (FORMAT BARU - TANPA KATA SINGGAH)
# =================================================================
Python
from kyt import *
import subprocess
import asyncio
import math
import time
import random
import requests
import datetime as DT
import os
from telethon.tl.custom import Button
from telethon import events
from telethon.errors import AlreadyInConversationError

# =================================================================
# FUNGSI PEMBANTU
# =================================================================
def get_ssh_data():
    try:
        cmd = '/usr/bin/kyt/shell/bot/bot-member-ssh'
        if not os.path.exists(cmd):
            cmd = 'bot-member-ssh'
        raw_output = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT).decode("utf-8")
        return [line for line in raw_output.splitlines() if line.strip()]
    except:
        return []

def render_page(data_list, page, item_per_page=10):
    total_items = len(data_list)
    total_pages = math.ceil(total_items / item_per_page)
    if page < 0: page = 0
    if total_pages > 0 and page >= total_pages: page = total_pages - 1
    start, end = page * item_per_page, (page * item_per_page) + item_per_page
    sliced_data = data_list[start:end]
    msg = "<b>━━━━━━━━━━━━━━━━━━━━━━━━━━━━</b>\n<b>👑 LIST MEMBER SSH & OVPN</b>\n<b>━━━━━━━━━━━━━━━━━━━━━━━━━━━━</b>\n"
    if not sliced_data:
        msg += "<i>Tidak ada user active.</i>"
    else:
        for row in sliced_data:
            try:
                p = row.split("|")
                icon = "🟢" if "UNLOCKED" in p[2] else "🔴"
                msg += f"<b>👤 User:</b> <code>{p[0]}</code>\n<b>📅 Exp:</b> <code>{p[1]}</code>\n<b>💎 Stat:</b> {icon} <code>{p[2]}</code>\n<b>━━━━━━━━━━━━━━━━━━━━</b>\n"
            except: continue
    msg += f"\n📊 Total: {total_items} | Page: {page+1}/{total_pages if total_pages > 0 else 1}"
    return msg, total_pages

# =================================================================
# 1. CREATE SSH (FULL REPAIRED)
# =================================================================
@bot.on(events.CallbackQuery(data=b'create-ssh'))
async def create_ssh(event):
    chat, sender = event.chat_id, await event.get_sender()
    if valid(str(sender.id)) != "true":
        await event.answer("Akses Ditolak", alert=True); return

    async with bot.conversation(chat, timeout=180) as convo:
        try:
            await event.respond('**Input Username:**'); user = (await convo.wait_event(events.NewMessage(incoming=True, from_users=sender.id))).raw_text
            if user == '/cancel': return
            await event.respond('**Input Password:**'); pw = (await convo.wait_event(events.NewMessage(incoming=True, from_users=sender.id))).raw_text
            await event.respond('**Input Limit IP:**'); limit = (await convo.wait_event(events.NewMessage(incoming=True, from_users=sender.id))).raw_text
            await event.respond('**Input Quota (GB):**'); quota = (await convo.wait_event(events.NewMessage(incoming=True, from_users=sender.id))).raw_text
            await event.respond('**Masa Aktif (Hari):**'); exp = (await convo.wait_event(events.NewMessage(incoming=True, from_users=sender.id))).raw_text
            
            msg_load = await event.respond("`Processing SSH Account...`")
            
            # --- LOGIC SYSTEM ---
            subprocess.run(f'useradd -e `date -d "{exp} days" +"%Y-%m-%d"` -s /bin/false -M {user} && echo "{user}:{pw}" | chpasswd', shell=True)
            subprocess.run(f'echo "{user} hard maxlogins {limit}" >> /etc/security/limits.conf', shell=True)
            
            today = DT.date.today()
            later = today + DT.timedelta(days=int(exp))
            
            # --- NOTIFIKASI 1: DETAIL AKUN ---
            msg_akun = f"""
**━━━━━━━━━━━━━━━━━**
**🐾🕊️ SSH OVPN ACCOUNT 🕊️🐾**
**━━━━━━━━━━━━━━━━━**
**» Username         :** `{user.strip()}`
**» Password         :** `{pw.strip()}`
**━━━━━━━━━━━━━━━━━**
**» Host             :** `{DOMAIN}`
**» Host Slowdns     :** `{HOST}`
**» Pub Key          :** `{PUB}`
**» Port OpenSSH     :** `443, 80, 22`
**» Port DNS         :** `443, 53 ,22`
**» Port Dropbear    :** `443, 109`
**» Port Dropbear WS :** `443, 109`
**» Port SSH WS      :** `80, 8080, 8081-9999 `
**» Port SSH SSL WS  :** `443`
**» Port SSL/TLS     :** `222-1000`
**» Port OVPN WS SSL :** `443`
**» Port OVPN SSL    :** `443`
**» Port OVPN TCP    :** `443, 1194`
**» Port OVPN UDP    :** `2200`
**» Proxy Squid      :** `3128`
**» BadVPN UDP       :** `7100, 7300, 7300`
**━━━━━━━━━━━━━━━━━**
**» Payload WS       :** `GET / HTTP/1.1[crlf]Host: {DOMAIN}[crlf]Upgrade: websocket[crlf][crlf]`
**━━━━━━━━━━━━━━━━━**
**» OpenVPN WS SSL   :** `https://{DOMAIN}:81/ws-ssl.ovpn`
**» OpenVPN SSL      :** `https://{DOMAIN}:81/ssl.ovpn`
**» OpenVPN TCP      :** `https://{DOMAIN}:81/tcp.ovpn`
**» OpenVPN UDP      :** `https://{DOMAIN}:81/udp.ovpn`
**━━━━━━━━━━━━━━━━━**
**» Save Link Account:** `https://{DOMAIN}:81/ssh-{user.strip()}.txt`
**» Expired Until:** `{later}`
**━━━━━━━━━━━━━━━━━**
**» SSH WS           :** `{DOMAIN}:80@{user.strip()}:{pw.strip()}`
**» SSH SSL          :** `{DOMAIN}:443@{user.strip()}:{pw.strip()}`
**» SSH UDP          :** `{DOMAIN}:1-65535@{user.strip()}:{pw.strip()}`
**━━━━━━━━━━━━━━━━━**
"""

            # --- NOTIFIKASI 2: STRUK PEMBELIAN (TANPA TOMBOL) ---
            msg_struk = f"""
``
◇━━━━━━━━━━━━━━━━━◇
*_PEMBELIAN BERHASIL_*
◇━━━━━━━━━━━━━━━━━◇
-» PRODUK : SSH
-» REGION : INDONESIA
-» REQ CONFIG : 
-» REQ NAMA : {user.strip()}
-» DEVICE : {limit.strip()} IP
-» HARGA : 
-» AKTIF : {exp} HARI
-» TGL EXP : {later}
◇━━━━━━━━━━━━━━━━━◇
``
"""
            await msg_load.delete()
            # Mengirim dua notifikasi terpisah
            await event.respond(msg_akun)
            await event.respond(msg_struk)

        except Exception as e:
            await event.respond(f"**Error:** `{e}`")

# =================================================================
# 2. DELETE & TRIAL SSH
# =================================================================
@bot.on(events.CallbackQuery(data=b'delete-ssh'))
async def delete_ssh(event):
    chat = event.chat_id
    sender = await event.get_sender()
    if valid(str(sender.id)) != "true": return
    
    async def delete_ssh_process():
        try:
            async with bot.conversation(chat, timeout=120) as user_convo:
                await event.respond("**Username To Be Deleted:**")
                user_event = await user_convo.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                user = user_event.raw_text
                
            cmd = f'userdel -f {user}'
            subprocess.run(cmd, shell=True)
            subprocess.run(f'sed -i "/^{user} hard maxlogins/d" /etc/security/limits.conf', shell=True)
            
            cmd_zivpn_del = f"""
            jq --arg u "{user}" '.auth.config -= [$u]' /etc/zivpn/config.json > /etc/zivpn/config.json.tmp && mv /etc/zivpn/config.json.tmp /etc/zivpn/config.json && \\
            jq --arg u "{user}" 'del(.[$u])' /etc/zivpn/user-db.json > /etc/zivpn/user-db.json.tmp && mv /etc/zivpn/user-db.json.tmp /etc/zivpn/user-db.json && \\
            systemctl restart zivpn
            """
            subprocess.run(cmd_zivpn_del, shell=True)
            await event.respond(f"**Deleted:** `{user}`", buttons=[[Button.inline("‹ Main Menu ›", "menu")]])
        except Exception as e:
            await event.respond(f"Error: {str(e)}")
    await delete_ssh_process()

@bot.on(events.CallbackQuery(data=b'trial-ssh'))
async def trial_ssh(event):
    chat = event.chat_id
    sender = await event.get_sender()
    if valid(str(sender.id)) != "true": return

    async def trial_ssh_process():
        try:
            async with bot.conversation(chat, timeout=60) as exp_convo:
                await event.respond("**Masa Aktif (Menit):**")
                exp_event = await exp_convo.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                exp_min = exp_event.raw_text

            user = "trial"+str(random.randint(100,999))
            pw = "1"
            cmd_sys = f'useradd -e "`date -d "{exp_min} minutes" +"%Y-%m-%d %H:%M:%S"`" -s /bin/false -M {user} && echo "{user}:{pw}" | chpasswd'
            subprocess.run(cmd_sys, shell=True)
            
            msg = f"**TRIAL SSH CREATED**\nUser: `{user}`\nPass: `{pw}`\nExp: `{exp_min} Min`"
            await event.respond(msg, buttons=[[Button.inline("‹ Main Menu ›", "menu")]])
        except: pass
    await trial_ssh_process()

# =================================================================
# 4. SHOW & LOGIN
# =================================================================
@bot.on(events.CallbackQuery(data=b'show-ssh'))
async def show_ssh(event):
    data_list = get_ssh_data()
    msg, total_pages = render_page(data_list, 0)
    await event.edit(msg, buttons=[[Button.inline("‹ Main Menu ›", "menu")]], parse_mode='html')

@bot.on(events.CallbackQuery(data=b'login-ssh'))
async def login_ssh(event):
    try:
        z = subprocess.check_output('bot-cek-login-ssh', shell=True).decode("utf-8")
        await event.respond(f"{z}", buttons=[[Button.inline("‹ Main Menu ›","menu")]])
    except: pass

# =================================================================
# 5. MENU UTAMA (KATA SINGGAH DIHAPUS)
# =================================================================
@bot.on(events.CallbackQuery(data=b'ssh'))
async def ssh(event):
    sender = await event.get_sender()
    if valid(str(sender.id)) != "true":
        await event.answer("Access Denied", alert=True)
        return
        
    try:
        inline = [
            [Button.inline(" TRIAL SSH ","trial-ssh"), Button.inline(" CREATE SSH ","create-ssh")],
            [Button.inline(" DELETE SSH ","delete-ssh"), Button.inline(" CHECK Login SSH ","login-ssh")],
            [Button.inline(" SHOW All USER SSH ","show-ssh"), Button.inline(" REGIS IP ","regis")],
            [Button.inline("‹ Main Menu ›","menu")]
        ]
        try:
             isp = subprocess.check_output("curl -s http://ip-api.com/json | jq -r .isp", shell=True).decode("utf-8").strip()
             country = subprocess.check_output("curl -s http://ip-api.com/json | jq -r .country", shell=True).decode("utf-8").strip()
        except:
             isp = "Unknown"
             country = "Unknown"

        msg = f"""
━━━━━━━━━━━━━━━━━━━━━━━ 
** PREMIUM TUNNELING **
━━━━━━━━━━━━━━━━━━━━━━━ 
━━━━━━━━━━━━━━━━━━━━━━━ 
 **⚠️ MENU SSH & OVPN ⚠️**
━━━━━━━━━━━━━━━━━━━━━━━ 
🟢 **» Service:** `SSH OVPN`
🟢 **» Hostname/IP:** `{DOMAIN}`
🟢 **» ISP:** `{isp}`
🟢 **» Country:** `{country}`
━━━━━━━━━━━━━━━━━━━━━━━ 
"""
        await event.edit(msg, buttons=inline)
    except Exception as e:
        await event.respond(f"Error: {str(e)}")