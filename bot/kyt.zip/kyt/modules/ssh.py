from kyt import *
import subprocess
import asyncio
import math
import time
import random
import requests
import datetime as DT
import os
from telethon.tl.custom import Button
from telethon import events
from telethon.errors import AlreadyInConversationError

# =================================================================
# FUNGSI PEMBANTU: AMBIL DATA & FORMAT PAGINATION
# =================================================================
def get_ssh_data():
    """Mengambil data raw dari script shell"""
    try:
        cmd = '/usr/bin/kyt/shell/bot/bot-member-ssh'
        if not os.path.exists(cmd):
            cmd = 'bot-member-ssh'
            
        raw_output = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT).decode("utf-8")
        data_list = [line for line in raw_output.splitlines() if line.strip()]
        return data_list
    except:
        return []

def render_page(data_list, page, item_per_page=10):
    total_items = len(data_list)
    total_pages = math.ceil(total_items / item_per_page)
    
    if page < 0: page = 0
    if total_pages > 0 and page >= total_pages: page = total_pages - 1
    if total_pages == 0: page = 0 
    
    start = page * item_per_page
    end = start + item_per_page
    sliced_data = data_list[start:end]
    
    msg = f"""
<b>━━━━━━━━━━━━━━━━━━━━━━━━━━━━</b>
<b> LIST MEMBER SSH & OVPN</b>
<b>━━━━━━━━━━━━━━━━━━━━━━━━━━━━</b>
"""
    if not sliced_data:
        msg += "<i>Tidak ada user ssh active.</i>"
    else:
        for row in sliced_data:
            try:
                parts = row.split("|")
                if len(parts) >= 3:
                    user = parts[0]
                    exp = parts[1]
                    status = parts[2]
                    icon_stat = "🟢" if "UNLOCKED" in status else "🔴"
                    msg += f"""
<b>User   :</b> <code>{user}</code>
<b>Exp    :</b> <code>{exp}</code>
<b>Status :</b> {icon_stat} <code>{status}</code>
<b>━━━━━━━━━━━━━━━━━━━━━━━━━━━━</b>
"""
                else: continue
            except: continue

    display_page = page + 1 if total_pages > 0 else 0
    msg += f"\n📊 <b>Total:</b> {total_items} Users | 📄 <b>Page:</b> {display_page}/{total_pages}"
    return msg, total_pages

# =================================================================
# 1. CREATE SSH (WITH ZIVPN INTEGRATION)
# =================================================================
@bot.on(events.CallbackQuery(data=b'create-ssh'))
async def create_ssh(event):
    chat = event.chat_id
    sender = await event.get_sender()
    
    if valid(str(sender.id)) != "true":
        await event.answer("Akses Ditolak", alert=True)
        return

    async def create_ssh_process():
        try:
            # 1. Input Username
            async with bot.conversation(chat, timeout=120) as user_convo:
                await event.respond('**Input Username:**\n(Ketik `/cancel` untuk batal)')
                user_event = await user_convo.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                if user_event.raw_text == '/cancel':
                    await event.respond("❌ **Proses Dibatalkan.**")
                    return
                user = user_event.raw_text
            
            # 2. Input Password
            async with bot.conversation(chat, timeout=120) as pw_convo:
                await event.respond("**Input Password:**")
                pw_event = await pw_convo.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                if pw_event.raw_text == '/cancel':
                    await event.respond("❌ **Proses Dibatalkan.**")
                    return
                pw = pw_event.raw_text
    
            # 3. Input Limit IP
            async with bot.conversation(chat, timeout=120) as limit_convo:
                await event.respond("**Input Max Login/IP :**")
                limit_event = await limit_convo.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                if limit_event.raw_text == '/cancel':
                    await event.respond("❌ **Proses Dibatalkan.**")
                    return
                limit = limit_event.raw_text

            # 4. Input Quota
            async with bot.conversation(chat, timeout=120) as quota_convo:
                await event.respond("**Input Quota :**")
                quota_event = await quota_convo.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                if quota_event.raw_text == '/cancel':
                    await event.respond("❌ **Proses Dibatalkan.**")
                    return
                quota = quota_event.raw_text
            
            # 5. Input Expired
            async with bot.conversation(chat, timeout=120) as exp_convo:
                await event.respond("**Input Masa Aktif:**")
                exp_event = await exp_convo.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                if exp_event.raw_text == '/cancel':
                    await event.respond("❌ **Proses Dibatalkan.**")
                    return
                exp = exp_event.raw_text
        
            msg_load = await event.respond("`Processing SSH & ZiVPN Account...`")
            
            # --- LOGIC UTAMA ---
            # 1. Buat User System (SSH)
            cmd_sys = f'useradd -e `date -d "{exp} days" +"%Y-%m-%d"` -s /bin/false -M {user} && echo "{user}:{pw}" | chpasswd && echo "{user} hard maxlogins {limit}" >> /etc/security/limits.conf'
            
            try:
                subprocess.check_output(cmd_sys, shell=True, stderr=subprocess.STDOUT)
                
                # 2. Jika sukses, Masukkan ke ZiVPN Database (Integrasi JSON)
                today = DT.date.today()
                later = today + DT.timedelta(days=int(exp))
                exp_date_str = later.strftime("%Y-%m-%d")
                
                # Command JQ untuk update Config & DB ZiVPN (Perhatikan double braces {{ }} untuk escape f-string)
                cmd_zivpn = f"""
                jq --arg u "{user}" '.auth.config += [$u]' /etc/zivpn/config.json > /etc/zivpn/config.json.tmp && mv /etc/zivpn/config.json.tmp /etc/zivpn/config.json && \\
                jq --arg u "{user}" --arg e "{exp_date_str}" --arg i "{limit}" --arg q "{quota}" '.[$u] = {{exp: $e, ip: $i, quota: $q}}' /etc/zivpn/user-db.json > /etc/zivpn/user-db.json.tmp && mv /etc/zivpn/user-db.json.tmp /etc/zivpn/user-db.json && \\
                systemctl restart zivpn
                """
                subprocess.run(cmd_zivpn, shell=True)

            except subprocess.CalledProcessError:
                await msg_load.delete()
                await event.respond("**User Already Exist / Error**", buttons=[[Button.inline("‹ Main Menu ›", "menu")]])
            else:
                created_date = today.strftime("%d/%m/%Y")
                msg = f"""
━━━━━━━━━━━━━━━━━
<b>AKUN SSH & ZIVPN</b>
━━━━━━━━━━━━━━━━━
Username: <code>{user.strip()}</code>
Password: <code>{pw.strip()}</code>
Domain: <code>{DOMAIN}</code>
ZiVPN: <code>{user.strip()}</code>

🔹 <b>PORT INFO</b>
━━━━━━━━━━━━━━━━━
SSH WS: <code>80</code>
SSH SSL: <code>443</code>
ZiVPN UDP: <code>5667</code> (UDP Custom)

🔹 <b>FORMAT  AKUN</b>
━━━━━━━━━━━━━━━━━
WS: <code>{DOMAIN}:80@{user.strip()}:{pw.strip()}</code>
SSL: <code>{DOMAIN}:443@{user.strip()}:{pw.strip()}</code>
UDP: <code>{DOMAIN}:1-65535@{user.strip()}:{pw.strip()}</code>

🔹 <b>PAYLOAD</b>
━━━━━━━━━━━━━━━━━
<code>GET / HTTP/1.1[crlf]Host: edu.ruangguru.com[crlf][crlf]PATCH / HTTP/1.1[crlf]Host: [host][crlf]Upgrade: websocket[crlf][crlf][split]HTTP/ 69[crlf][crlf]</code>

<code>GET /cdn-cgi/trace HTTP/1.1[crlf]Host: bug.com[crlf][crlf]GET-RAY / HTTP/1.1[crlf]Host: [host][crlf]Connection: Upgrade[crlf]User-Agent: [ua][crlf]Upgrade: websocket[crlf][crlf]</code>
━━━━━━━━━━━━━━━━━
Expired: <code>{later}</code>
IP Limit: <code>{limit.strip()} Device</code>
Quota: <code>{quota.strip()} GB</code>

``
◇━━━━━━━━━━━━━━━━━◇
*_PEMBELIAN BERHASIL_*
◇━━━━━━━━━━━━━━━━━◇
-» PRODUK : SSH
-» REGION : {city.strip()}
-» REQ CONFIG : 
-» REQ NAMA : {user.strip()}
-» DEVICE : {limit.strip()} IP
-» HARGA : 
-» AKTIF : {exp} HARI
-» TGL EXP : {later}
◇━━━━━━━━━━━━━━━━━◇
*_TERIMAKASIH TELAH ORDER_*
◇━━━━━━━━━━━━━━━━━◇
``
"""
                await msg_load.delete()
                await event.respond(msg, parse_mode='html', buttons=[[Button.inline("")]])

        except AlreadyInConversationError:
            await event.answer("⚠️ Sedang ada proses lain! Ketik /cancel dulu.", alert=True)
        except asyncio.TimeoutError:
            await event.respond("**Waktu Habis.**", buttons=[[Button.inline("‹ Main Menu ›", "menu")]])
        except Exception as e:
            await event.respond(f"**Error:** `{str(e)}`", buttons=[[Button.inline("‹ Main Menu ›", "menu")]])

    await create_ssh_process()

# =================================================================
# 2. DELETE SSH (WITH ZIVPN CLEANUP)
# =================================================================
@bot.on(events.CallbackQuery(data=b'delete-ssh'))
async def delete_ssh(event):
    chat = event.chat_id
    sender = await event.get_sender()
    
    if valid(str(sender.id)) != "true":
        await event.answer("Akses Ditolak", alert=True)
        return

    async def delete_ssh_process():
        try:
            async with bot.conversation(chat, timeout=120) as user_convo:
                await event.respond("**Username To Be Deleted:**\n(Ketik `/cancel` untuk batal)")
                user_event = await user_convo.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                if user_event.raw_text == '/cancel':
                    await event.respond("❌ **Proses Dibatalkan.**")
                    return
                user = user_event.raw_text
                
            cmd = f'userdel -f {user}'
            
            try:
                subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT)
            except subprocess.CalledProcessError:
                await event.respond(f"**User** `{user}` **Not Found in System**", buttons=[[Button.inline("‹ Main Menu ›", "menu")]])
            else:
                # 1. Hapus Limit IP SSH
                subprocess.run(f'sed -i "/^{user} hard maxlogins/d" /etc/security/limits.conf', shell=True)
                
                # 2. Hapus dari ZiVPN Database
                cmd_zivpn_del = f"""
                jq --arg u "{user}" '.auth.config -= [$u]' /etc/zivpn/config.json > /etc/zivpn/config.json.tmp && mv /etc/zivpn/config.json.tmp /etc/zivpn/config.json && \\
                jq --arg u "{user}" 'del(.[$u])' /etc/zivpn/user-db.json > /etc/zivpn/user-db.json.tmp && mv /etc/zivpn/user-db.json.tmp /etc/zivpn/user-db.json && \\
                systemctl restart zivpn
                """
                subprocess.run(cmd_zivpn_del, shell=True)
                
                await event.respond(f"**Successfully Deleted SSH & ZiVPN:** `{user}`", buttons=[[Button.inline("‹ Main Menu ›", "menu")]])
                
        except AlreadyInConversationError:
            await event.answer("⚠️ Sedang ada proses lain! Ketik /cancel dulu.", alert=True)
        except asyncio.TimeoutError:
            await event.respond("**Timeout.**", buttons=[[Button.inline("‹ Main Menu ›", "menu")]])
        except Exception as e:
            await event.respond(f"**Error:** `{str(e)}`", buttons=[[Button.inline("‹ Main Menu ›", "menu")]])
            
    await delete_ssh_process()

# =================================================================
# 3. TRIAL SSH (WITH ZIVPN INTEGRATION)
# =================================================================
@bot.on(events.CallbackQuery(data=b'trial-ssh'))
async def trial_ssh(event):
    chat = event.chat_id
    sender = await event.get_sender()

    if valid(str(sender.id)) != "true":
        await event.answer("Akses Ditolak", alert=True)
        return

    async def trial_ssh_process():
        try:
            async with bot.conversation(chat, timeout=60) as exp_convo:
                await event.respond("**Input Masa Aktif (Menit):**\n`Contoh: 30`\n(Ketik `/cancel` untuk batal)")
                exp_event = await exp_convo.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                if exp_event.raw_text == '/cancel':
                    await event.respond("❌ **Proses Dibatalkan.**")
                    return
                exp = exp_event.raw_text
                if not exp.isdigit():
                     await event.respond("**Error:** Harap masukkan angka saja.")
                     return

            user = "trialX"+str(random.randint(100,1000))
            pw = "1"
            limit = "1"
            quota = "1"
            created_date = DT.date.today().strftime("%d/%m/%Y")
            
            msg_load = await event.respond("`Creating Trial SSH & ZiVPN...`")
            
            # 1. Create System User
            cmd_sys = f'useradd -e "`date -d "{exp} minutes" +"%Y-%m-%d %H:%M:%S"`" -s /bin/false -M {user} && echo "{user}:{pw}" | chpasswd && echo "{user} hard maxlogins 1" >> /etc/security/limits.conf'
            
            try:
                subprocess.check_output(cmd_sys, shell=True, stderr=subprocess.STDOUT)
                
                # 2. Add to ZiVPN (Untuk trial, kita set exp date ke BESOK agar user bisa connect hari ini)
                # ZiVPN logic expirednya per tanggal (YYYY-MM-DD), tidak support per menit secara native di DB.
                tomorrow = DT.date.today() + DT.timedelta(days=1)
                exp_date_str = tomorrow.strftime("%Y-%m-%d")
                
                cmd_zivpn = f"""
                jq --arg u "{user}" '.auth.config += [$u]' /etc/zivpn/config.json > /etc/zivpn/config.json.tmp && mv /etc/zivpn/config.json.tmp /etc/zivpn/config.json && \\
                jq --arg u "{user}" --arg e "{exp_date_str}" --arg i "{limit}" --arg q "{quota}" '.[$u] = {{exp: $e, ip: $i, quota: $q}}' /etc/zivpn/user-db.json > /etc/zivpn/user-db.json.tmp && mv /etc/zivpn/user-db.json.tmp /etc/zivpn/user-db.json && \\
                systemctl restart zivpn
                """
                subprocess.run(cmd_zivpn, shell=True)

            except subprocess.CalledProcessError:
                await msg_load.delete()
                await event.respond("**Failed to create trial.**", buttons=[[Button.inline("‹ Main Menu ›", "menu")]])
            else:
                msg = f"""
━━━━━━━━━━━━━━━━━━━━━━━
 <b>TRIAL SSH & ZIVPN</b>
━━━━━━━━━━━━━━━━━━━━━━━

🔹 <b>INFORMASI AKUN</b>
━━━━━━━━━━━━━━━━━━━━━━━
Username: <code>{user.strip()}</code>
Password: <code>{pw.strip()}</code>
Domain: <code>{DOMAIN}</code>
Limit IP: <code>1 Device</code>

🔹 <b>FORMAT AKUN</b>
━━━━━━━━━━━━━━━━━━━━━━━
WS: <code>{DOMAIN}:80@{user.strip()}:{pw.strip()}</code>
SSL: <code>{DOMAIN}:443@{user.strip()}:{pw.strip()}</code>
UDP: <code>{DOMAIN}:1-65535@{user.strip()}:{pw.strip()}</code>

🔹 <b>PAYLOAD</b>
━━━━━━━━━━━━━━━━━━━━━━━
<code>GET / HTTP/1.1[crlf]Host: edu.ruangguru.com[crlf][crlf]PATCH / HTTP/1.1[crlf]Host: [host][crlf]Upgrade: websocket[crlf][crlf][split]HTTP/ 69[crlf][crlf]</code>

<code>GET /cdn-cgi/trace HTTP/1.1[crlf]Host: bug.com[crlf][crlf]GET-RAY / HTTP/1.1[crlf]Host: [host][crlf]Connection: Upgrade[crlf]User-Agent: [ua][crlf]Upgrade: websocket[crlf][crlf]</code>
━━━━━━━━━━━━━━━━━━━━━━━
Expired: <code>{exp} Minutes</code>
Quota: <code>1 GB</code>
━━━━━━━━━━━━━━━━━━━━━━━
WONG NDEZO OFFICIAL 
━━━━━━━━━━━━━━━━━━━━━━━
"""
                await msg_load.delete()
                await event.respond(msg, parse_mode='html', buttons=[[Button.inline("‹ Main Menu ›", "menu")]])
        
        except AlreadyInConversationError:
            await event.answer("⚠️ Sedang ada proses lain! Ketik /cancel dulu.", alert=True)
        except Exception as e:
            await event.respond(f"**Error:** `{str(e)}`", buttons=[[Button.inline("‹ Main Menu ›", "menu")]])

    await trial_ssh_process()

# =================================================================
# 4. SHOW SSH
# =================================================================
@bot.on(events.CallbackQuery(data=b'show-ssh'))
async def show_ssh(event):
    sender = await event.get_sender()
    if valid(str(sender.id)) != "true":
        await event.answer("Access Denied", alert=True)
        return

    data_list = get_ssh_data()
    msg, total_pages = render_page(data_list, 0)
    
    buttons = []
    if total_pages > 1:
        buttons.append([Button.inline("Next ⏩", data=f"sshPage_1")])
    buttons.append([Button.inline("‹ Main Menu ›", "menu")])
    
    try: await event.edit(msg, buttons=buttons, parse_mode='html')
    except: await event.reply(msg, buttons=buttons, parse_mode='html')

@bot.on(events.CallbackQuery(pattern=b'sshPage_(\d+)'))
async def paginate_ssh(event):
    sender = await event.get_sender()
    if valid(str(sender.id)) != "true":
        await event.answer("Access Denied", alert=True)
        return

    try: page = int(event.data.decode().split('_')[1])
    except: page = 0
    
    data_list = get_ssh_data()
    msg, total_pages = render_page(data_list, page)
    
    nav_buttons = []
    if page > 0: nav_buttons.append(Button.inline("⏪ Prev", data=f"sshPage_{page-1}"))
    if page < total_pages - 1: nav_buttons.append(Button.inline("Next ⏩", data=f"sshPage_{page+1}"))
    
    buttons = []
    if nav_buttons: buttons.append(nav_buttons)
    buttons.append([Button.inline("‹ Main Menu ›", "menu")])
    
    try: await event.edit(msg, buttons=buttons, parse_mode='html')
    except: await event.answer("Halaman tidak berubah")

# =================================================================
# 5. LOGIN SSH
# =================================================================
@bot.on(events.CallbackQuery(data=b'login-ssh'))
async def login_ssh(event):
    async def login_ssh_(event):
        try:
            cmd = 'bot-cek-login-ssh'.strip()
            z = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT).decode("utf-8")
            
            if len(z) > 4000:
                nama_file = "login_ssh.txt"
                with open(nama_file, "w") as f:
                    f.write(z)
                await event.client.send_file(
                    event.chat_id,
                    nama_file,
                    caption="⚠️ **List Login Terlalu Panjang!**",
                    buttons=[[Button.inline("‹ Main Menu ›","menu")]]
                )
                os.remove(nama_file)
            else:
                await event.respond(f"{z}\n**Check Login SSH**", buttons=[[Button.inline("‹ Main Menu ›","menu")]])
        except Exception as e:
            await event.respond(f"**Error:** `{str(e)}`")

    sender = await event.get_sender()
    if valid(str(sender.id)) == "true":
        await login_ssh_(event)
    else:
        await event.answer("Access Denied", alert=True)

# =================================================================
# 6. MENU UTAMA SSH
# =================================================================
@bot.on(events.CallbackQuery(data=b'ssh'))
async def ssh(event):
    sender = await event.get_sender()
    if valid(str(sender.id)) != "true":
        await event.answer("Access Denied", alert=True)
        return
        
    try:
        inline = [
            [Button.inline(" TRIAL SSH ","trial-ssh"), Button.inline(" CREATE SSH ","create-ssh")],
            [Button.inline(" DELETE SSH ","delete-ssh"), Button.inline(" CHECK Login SSH ","login-ssh")],
            [Button.inline(" SHOW All USER SSH ","show-ssh"), Button.inline(" REGIS IP ","regis")],
            [Button.inline("‹ Main Menu ›","menu")]
        ]
        try:
             isp = subprocess.check_output("curl --max-time 2 -s http://ip-api.com/json | python3 -c \"import sys, json; print(json.load(sys.stdin).get('isp', 'Unknown'))\"", shell=True).decode("utf-8").strip()
             country = subprocess.check_output("curl --max-time 2 -s http://ip-api.com/json | python3 -c \"import sys, json; print(json.load(sys.stdin).get('country', 'Unknown'))\"", shell=True).decode("utf-8").strip()
        except:
             isp = "Unknown"
             country = "Unknown"

        msg = f"""
━━━━━━━━━━━━━━━━━━━━━━━ 
** WONG NDEZO TUNNELING **
━━━━━━━━━━━━━━━━━━━━━━━ 
━━━━━━━━━━━━━━━━━━━━━━━ 
 **⚠️ MENU SSH & OVPN ⚠️**
━━━━━━━━━━━━━━━━━━━━━━━ 
🟢 **» Service:** `SSH OVPN`
🟢 **» Hostname/IP:** `{DOMAIN}`
🟢 **» ISP:** `{isp}`
🟢 **» Country:** `{country}`
🇮🇩 **» @Ultramenstor**
━━━━━━━━━━━━━━━━━━━━━━━ 
"""
        await event.edit(msg, buttons=inline)
    except Exception as e:
        await event.respond(f"Error: {str(e)}")