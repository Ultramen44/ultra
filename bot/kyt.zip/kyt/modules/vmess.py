from kyt import *

# CREATE VMESS
@bot.on(events.CallbackQuery(data=b'create-vmess'))
async def create_vmess(event):
    async def create_vmess_(event):
        chat = event.chat_id
        sender = await event.get_sender()
        
        async with bot.conversation(chat) as user_conv:
            await event.respond('**Username:**')
            user_msg = await user_conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            user_input = user_msg.raw_text
        
        async with bot.conversation(chat) as quota_conv:
            await event.respond("**Quota (GB):**")
            quota_msg = await quota_conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            quota_input = quota_msg.raw_text
            
        async with bot.conversation(chat) as exp_conv:
            await event.respond("**Input Expired Day (Angka):**")
            exp_msg = await exp_conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            exp_input = exp_msg.raw_text

        await event.respond("`Processing... Setting up an Account`")
        
        # Command execution
        cmd = f'printf "%s\n" "{user_input}" "{exp_input}" "{quota_input}" | addws-bot'
        try:
            a = subprocess.check_output(cmd, shell=True).decode("utf-8")
        except:
            await event.respond("**User Already Exist or Error in Script**")
            return

        # Ambil info lokasi untuk detail pembelian
        try:
            geo = requests.get(f"http://ip-api.com/json/").json()
            city = geo.get("city", "Unknown")
        except:
            city = "Unknown"

        today = DT.date.today()
        later = today + DT.timedelta(days=int(exp_input))
        
        # Parsing vmess links
        b = [x.group() for x in re.finditer("vmess://(.*)", a)]
        if len(b) < 3:
            await event.respond("**Error: Gagal generate link Vmess**")
            return

        z = json.loads(base64.b64decode(b[0].replace("vmess://","")).decode("ascii"))
        
        link_tls = b[0].strip("'").replace(" ","")
        link_ntls = b[1].strip("'").replace(" ","")
        link_grpc = b[2].strip("'")

        # Tampilan Pesan Gabungan
        msg = f"""
**━━━━━━━━━━━━━━━━━**
 **🟢 VMESS ACCOUNT 🟢**
**━━━━━━━━━━━━━━━━━**
**» Username     :** `{z["ps"]}`
**» Domain       :** `{z["add"]}`
**» User Quota   :** `{quota_input} GB`
**» Port TLS     :** `443`
**» Port NTLS    :** `80, 8080`
**» User ID      :** `{z["id"]}`
**» NetWork      :** `WS / GRPC`
**» Path         :** `/vmess`
**━━━━━━━━━━━━━━━━━**
**» Link TLS (Click to Copy):**
<code>{link_tls}</code>
**━━━━━━━━━━━━━━━━━**
**» Link NTLS (Click to Copy):**
<code>{link_ntls}</code>
**━━━━━━━━━━━━━━━━━**
**» Link GRPC (Click to Copy):**
<code>{link_grpc}</code>
**━━━━━━━━━━━━━━━━━**
**» Format OpenClash :** `https://{DOMAIN}:81/vmess-{user_input}.txt`
**━━━━━━━━━━━━━━━━━**
**» Expired On   :** `{later}`
**━━━━━━━━━━━━━━━━━**

<code>◇━━━━━━━━━━━━━━━━━◇
  PEMBELIAN BERHASIL
◇━━━━━━━━━━━━━━━━━◇
-» PRODUK : VMESS
-» REGION : {city}
-» REQ CONFIG : WS/GRPC
-» REQ NAMA : {user_input}
-» DEVICE : {quota_input} GB
-» HARGA : -
-» AKTIF : {exp_input} HARI
-» TGL EXP : {later}
◇━━━━━━━━━━━━━━━━━◇</code>
"""
        await event.respond(msg, parse_mode='html')

    chat = event.chat_id
    sender = await event.get_sender()
    if valid(str(sender.id)) == "true":
        await create_vmess_(event)
    else:
        await event.answer("Akses Ditolak", alert=True)

# TRIAL VMESS
@bot.on(events.CallbackQuery(data=b'trial-vmess'))
async def trial_vmess(event):
    async def trial_vmess_(event):
        async with bot.conversation(chat) as exp_conv:
            await event.respond("**Choose Expiry Minutes**", buttons=[
                [Button.inline(" 10 Menit ","10"), Button.inline(" 15 Menit ","15")],
                [Button.inline(" 30 Menit ","30"), Button.inline(" 60 Menit ","60")]
            ])
            exp_res = await exp_conv.wait_event(events.CallbackQuery)
            exp_val = exp_res.data.decode("ascii")
        
        await event.edit("`Processing Trial Account...`")
        cmd = f'printf "%s\n" "{exp_val}" | bot-trialws'
        try:
            a = subprocess.check_output(cmd, shell=True).decode("utf-8")
            b = [x.group() for x in re.finditer("vmess://(.*)", a)]
            z = json.loads(base64.b64decode(b[0].replace("vmess://","")).decode("ascii"))
            
            msg = f"""
**━━━━━━━━━━━━━━━━━**
 **🟡 TRIAL VMESS 🟡**
**━━━━━━━━━━━━━━━━━**
**» Remarks      :** `{z["ps"]}`
**» User ID      :** `{z["id"]}`
**» Expired      :** `{exp_val} Minutes`
**━━━━━━━━━━━━━━━━━**
**» Link TLS :**
<code>{b[0].strip("'").replace(" ","")}</code>
**━━━━━━━━━━━━━━━━━**
**» Link NTLS :**
<code>{b[1].strip("'").replace(" ","")}</code>
**━━━━━━━━━━━━━━━━━**
**» Link GRPC :**
<code>{b[2].strip("'")}</code>
**━━━━━━━━━━━━━━━━━**
**»☎️ @Ultramenstor**
"""
            await event.respond(msg, parse_mode='html')
        except:
            await event.respond("**Error creating trial**")

    chat = event.chat_id
    sender = await event.get_sender()
    if valid(str(sender.id)) == "true":
        await trial_vmess_(event)
    else:
        await event.answer("Akses Ditolak", alert=True)

# CEK VMESS
@bot.on(events.CallbackQuery(data=b'cek-vmess'))
async def cek_vmess(event):
    async def cek_vmess_(event):
        try:
            z = subprocess.check_output('bot-cek-ws', shell=True).decode("utf-8")
            await event.respond(f"**Logged In Users Vmess**\n\n`{z}`", buttons=[[Button.inline("‹ Main Menu ›","menu")]])
        except:
            await event.respond("Gagal mengambil data user.")

    sender = await event.get_sender()
    if valid(str(sender.id)) == "true":
        await cek_vmess_(event)
    else:
        await event.answer("Access Denied", alert=True)

# DELETE VMESS
@bot.on(events.CallbackQuery(data=b'delete-vmess'))
async def delete_vmess(event):
    async def delete_vmess_(event):
        async with bot.conversation(chat) as user_conv:
            await event.respond('**Username to Delete:**')
            user_msg = await user_conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            user_del = user_msg.raw_text
        
        cmd = f'printf "%s\n" "{user_del}" | bot-delws'
        subprocess.check_output(cmd, shell=True)
        await event.respond(f"**User {user_del} Successfully Deleted**")

    chat = event.chat_id
    sender = await event.get_sender()
    if valid(str(sender.id)) == "true":
        await delete_vmess_(event)
    else:
        await event.answer("Akses Ditolak", alert=True)

# MENU VMESS
@bot.on(events.CallbackQuery(data=b'vmess'))
async def vmess(event):
    async def vmess_(event):
        inline = [
            [Button.inline(" TRIAL VMESS ","trial-vmess"), Button.inline(" CREATE VMESS ","create-vmess")],
            [Button.inline(" CHECK VMESS ","cek-vmess"), Button.inline(" DELETE VMESS ","delete-vmess")],
            [Button.inline("‹ Main Menu ›","menu")]
        ]
        try:
            z = requests.get(f"http://ip-api.com/json/").json()
            isp = z.get("isp", "Unknown")
            country = z.get("country", "Unknown")
        except:
            isp, country = "Unknown", "Unknown"

        msg = f"""
━━━━━━━━━━━━━━━━━━━━━━━ 
**🇮🇩 WONG NDEZO TUNNELING 🇮🇩**
━━━━━━━━━━━━━━━━━━━━━━━ 
       **⚠️ MENU VMESS ⚠️**
━━━━━━━━━━━━━━━━━━━━━━━ 
🟢 **» Service:** `VMESS`
🟢 **» Hostname/IP:** `{DOMAIN}`
🟢 **» ISP:** `{isp}`
🟢 **» Country:** `{country}`
━━━━━━━━━━━━━━━━━━━━━━━ 
"""
        await event.edit(msg, buttons=inline)

    sender = await event.get_sender()
    if valid(str(sender.id)) == "true":
        await vmess_(event)
    else:
        await event.answer("Access Denied", alert=True)