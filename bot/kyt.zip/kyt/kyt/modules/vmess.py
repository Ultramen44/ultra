from kyt import *
import math
import datetime as DT

# =================================================================
# FUNGSI PEMBANTU: AMBIL DATA VMESS & FORMAT PAGINATION
# =================================================================
def get_vmess_data():
    """Mengambil data user dari config.json xray"""
    try:
        # Ambil baris yang diawali ### (Format: ### user exp)
        cmd = 'grep -E "^### " /etc/xray/config.json | sort | uniq'
        raw_output = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT).decode("utf-8")
        
        data_list = []
        today = DT.date.today()
        
        for line in raw_output.splitlines():
            # Format baris biasanya: ### username exp_date
            parts = line.split() 
            if len(parts) >= 3:
                username = parts[1]
                exp_date_str = parts[2]
                
                # Logic Cek Status Expired
                try:
                    exp_date = DT.datetime.strptime(exp_date_str, "%Y-%m-%d").date()
                    days_left = (exp_date - today).days
                    
                    if days_left >= 0:
                        status = "ACTIVE"
                        icon = "🟢"
                    else:
                        status = "EXPIRED"
                        icon = "🔴"
                except ValueError:
                    status = "LIFETIME"
                    icon = "🟢"
                
                # Masukkan ke list
                data_list.append(f"{username}|{exp_date_str}|{status}|{icon}")
                
        return data_list
    except Exception as e:
        return []

def render_vmess_page(data_list, page, item_per_page=10):
    total_items = len(data_list)
    total_pages = math.ceil(total_items / item_per_page)
    
    if page < 0: page = 0
    if total_pages > 0 and page >= total_pages: page = total_pages - 1
    if total_pages == 0: page = 0 
    
    start = page * item_per_page
    end = start + item_per_page
    sliced_data = data_list[start:end]
    
    msg = f"""
<b>━━━━━━━━━━━━━━━━━━━━━━━━━━━━</b>
<b>👥 LIST MEMBER XRAY / VMESS</b>
<b>━━━━━━━━━━━━━━━━━━━━━━━━━━━━</b>
"""
    if not sliced_data:
        msg += "<i>Tidak ada user vmess active.</i>"
    else:
        for row in sliced_data:
            try:
                parts = row.split("|")
                user = parts[0]
                exp = parts[1]
                status = parts[2]
                icon = parts[3]
                
                msg += f"""
<b>👤 User   :</b> <code>{user}</code>
<b>📅 Exp    :</b> <code>{exp}</code>
<b>💎 Status :</b> {icon} <code>{status}</code>
<b>━━━━━━━━━━━━━━━━━━━━━━━━━━━━</b>
"""
            except: continue

    display_page = page + 1 if total_pages > 0 else 0
    msg += f"\n📊 <b>Total:</b> {total_items} Users | 📄 <b>Page:</b> {display_page}/{total_pages}"
    return msg, total_pages

# =================================================================
# 1. CREATE VMESS
# =================================================================
@bot.on(events.CallbackQuery(data=b'create-vmess'))
async def create_vmess(event):
    async def create_vmess_(event):
        async with bot.conversation(chat) as user_convo:
            await event.respond('**Input Username:**')
            user = (await user_convo.wait_event(events.NewMessage(incoming=True, from_users=sender.id))).raw_text
        
        async with bot.conversation(chat) as quota_convo:
            await event.respond("**Input Quota (GB):**")
            pw = (await quota_convo.wait_event(events.NewMessage(incoming=True, from_users=sender.id))).raw_text
            
        async with bot.conversation(chat) as exp_convo:
            await event.respond("**Choose Expiry Day**", buttons=[
                [Button.inline(" 3 Day ","3"), Button.inline(" 7 Day ","7")],
                [Button.inline(" 30 Day ","30"), Button.inline(" 60 Day ","60")]
            ])
            exp = (await exp_convo.wait_event(events.CallbackQuery)).data.decode("ascii")

        msg_load = await event.respond("`Processing...`")
        time.sleep(1)
        
        cmd = f'printf "%s\n" "{user}" "{exp}" "{pw}" | addws-bot'
        try:
            a = subprocess.check_output(cmd, shell=True).decode("utf-8")
        except:
            await msg_load.delete()
            await event.respond("**User Already Exist**", buttons=[[Button.inline("‹ Main Menu ›", "vmess")]])
        else:
            today = DT.date.today()
            later = today + DT.timedelta(days=int(exp))
            b = [x.group() for x in re.finditer("vmess://(.*)", a)]
            z = json.loads(base64.b64decode(b[0].replace("vmess://", "")).decode("ascii"))
            
            msg = f"""
<b>━━━━━━━━━━━━━━━━━━━━━━━━━━━━</b>
<b>🟢 XRAY / VMESS ACCOUNT</b>
<b>━━━━━━━━━━━━━━━━━━━━━━━━━━━━</b>

<b>🔹 INFORMASI AKUN</b>
<b>👤 Remarks   :</b> <code>{z["ps"]}</code>
<b>🌐 Domain    :</b> <code>{z["add"]}</code>
<b>📦 Quota     :</b> <code>{pw} GB</code>
<b>🆔 User ID   :</b> <code>{z["id"]}</code>
<b>🔒 Security  :</b> <code>auto</code>
<b>📡 Network   :</b> <code>ws / grpc</code>
<b>🛣️ Path      :</b> <code>/vmess</code>

<b>🔗 LINK CONNECTION</b>
<b>🔑 TLS  :</b> <code>{b[0].strip("'")}</code>
<b>🔓 NTLS :</b> <code>{b[1].strip("'")}</code>
<b>💠 GRPC :</b> <code>{b[2].strip("'")}</code>

<b>📅 Expired On :</b> <code>{later}</code>
<b>━━━━━━━━━━━━━━━━━━━━━━━━━━━━</b>
"""
            await msg_load.delete()
            await event.respond(msg, parse_mode='html', buttons=[[Button.inline("‹ Main Menu ›", "vmess")]])

    chat = event.chat_id
    sender = await event.get_sender()
    if valid(str(sender.id)) == "true":
        await create_vmess_(event)
    else:
        await event.answer("Akses Ditolak", alert=True)

# =================================================================
# 2. TRIAL VMESS
# =================================================================
@bot.on(events.CallbackQuery(data=b'trial-vmess'))
async def trial_vmess(event):
    async def trial_vmess_(event):
        async with bot.conversation(chat) as exp_convo:
            await event.respond("**Choose Expiry Minutes**", buttons=[
                [Button.inline(" 15 Menit ","15"), Button.inline(" 30 Menit ","30")],
                [Button.inline(" 60 Menit ","60")]
            ])
            exp = (await exp_convo.wait_event(events.CallbackQuery)).data.decode("ascii")

        msg_load = await event.respond("`Creating Trial...`")
        time.sleep(1)
        
        cmd = f'printf "%s\n" "{exp}" | bot-trialws'
        try:
            a = subprocess.check_output(cmd, shell=True).decode("utf-8")
        except:
            await msg_load.delete()
            await event.respond("**Error creating trial**", buttons=[[Button.inline("‹ Main Menu ›", "vmess")]])
        else:
            b = [x.group() for x in re.finditer("vmess://(.*)", a)]
            z = json.loads(base64.b64decode(b[0].replace("vmess://", "")).decode("ascii"))
            
            msg = f"""
<b>━━━━━━━━━━━━━━━━━━━━━━━━━━━━</b>
<b>🟡 TRIAL VMESS ACCOUNT</b>
<b>━━━━━━━━━━━━━━━━━━━━━━━━━━━━</b>

<b>👤 Remarks   :</b> <code>{z["ps"]}</code>
<b>🌐 Domain    :</b> <code>{z["add"]}</code>
<b>⏳ Expired   :</b> <code>{exp} Minutes</code>

<b>🔗 LINK CONNECTION</b>
<b>🔑 TLS  :</b> <code>{b[0].strip("'")}</code>
<b>🔓 NTLS :</b> <code>{b[1].strip("'")}</code>
<b>━━━━━━━━━━━━━━━━━━━━━━━━━━━━</b>
"""
            await msg_load.delete()
            await event.respond(msg, parse_mode='html', buttons=[[Button.inline("‹ Main Menu ›", "vmess")]])

    chat = event.chat_id
    sender = await event.get_sender()
    if valid(str(sender.id)) == "true":
        await trial_vmess_(event)
    else:
        await event.answer("Akses Ditolak", alert=True)

# =================================================================
# 3. DELETE VMESS
# =================================================================
@bot.on(events.CallbackQuery(data=b'delete-vmess'))
async def delete_vmess(event):
    async def delete_vmess_(event):
        async with bot.conversation(chat) as user_convo:
            await event.respond('**Input Username to Delete:**')
            user = (await user_convo.wait_event(events.NewMessage(incoming=True, from_users=sender.id))).raw_text
            
        cmd = f'printf "%s\n" "{user}" | bot-delws'
        try:
            subprocess.check_output(cmd, shell=True).decode("utf-8")
        except:
            await event.respond("**User Not Found**", buttons=[[Button.inline("‹ Main Menu ›", "vmess")]])
        else:
            await event.respond(f"✅ **Successfully Deleted** `{user}`", buttons=[[Button.inline("‹ Main Menu ›", "vmess")]])

    chat = event.chat_id
    sender = await event.get_sender()
    if valid(str(sender.id)) == "true":
        await delete_vmess_(event)
    else:
        await event.answer("Akses Ditolak", alert=True)

# =================================================================
# 4. CHECK USER LOGIN VMESS
# =================================================================
@bot.on(events.CallbackQuery(data=b'cek-vmess'))
async def cek_vmess(event):
    async def cek_vmess_(event):
        cmd = 'bot-cek-ws'.strip()
        z = subprocess.check_output(cmd, shell=True).decode("utf-8")
        await event.respond(f"""
<b>━━━━━━━━━━━━━━━━━━━━━━━━━━━━</b>
<b>👀 ONLINE USER VMESS</b>
<b>━━━━━━━━━━━━━━━━━━━━━━━━━━━━</b>
{z}
""", parse_mode='html', buttons=[[Button.inline("‹ Main Menu ›", "vmess")]])

    sender = await event.get_sender()
    if valid(str(sender.id)) == "true":
        await cek_vmess_(event)
    else:
        await event.answer("Access Denied", alert=True)

# =================================================================
# 5. SHOW ALL USER VMESS (PAGINATION)
# =================================================================
@bot.on(events.CallbackQuery(data=b'list-vmess'))
async def list_vmess(event):
    sender = await event.get_sender()
    if valid(str(sender.id)) != "true":
        await event.answer("Access Denied", alert=True)
        return

    data_list = get_vmess_data()
    msg, total_pages = render_vmess_page(data_list, 0)
    
    buttons = []
    if total_pages > 1:
        buttons.append([Button.inline("Next ⏩", data=f"vmessPage_1")])
    buttons.append([Button.inline("‹ Back to Menu ›", "vmess")])
    
    try: await event.edit(msg, buttons=buttons, parse_mode='html')
    except: await event.reply(msg, buttons=buttons, parse_mode='html')

@bot.on(events.CallbackQuery(pattern=b'vmessPage_(\d+)'))
async def paginate_vmess(event):
    sender = await event.get_sender()
    if valid(str(sender.id)) != "true":
        await event.answer("Access Denied", alert=True)
        return

    try: page = int(event.data.decode().split('_')[1])
    except: page = 0
    
    data_list = get_vmess_data()
    msg, total_pages = render_vmess_page(data_list, page)
    
    nav_buttons = []
    if page > 0: nav_buttons.append(Button.inline("⏪ Prev", data=f"vmessPage_{page-1}"))
    if page < total_pages - 1: nav_buttons.append(Button.inline("Next ⏩", data=f"vmessPage_{page+1}"))
    
    buttons = []
    if nav_buttons: buttons.append(nav_buttons)
    buttons.append([Button.inline("‹ Back to Menu ›", "vmess")])
    
    try: await event.edit(msg, buttons=buttons, parse_mode='html')
    except: await event.answer("Halaman tidak berubah")

# =================================================================
# 6. MAIN MENU VMESS
# =================================================================
@bot.on(events.CallbackQuery(data=b'vmess'))
async def vmess(event):
    sender = await event.get_sender()
    if valid(str(sender.id)) != "true":
        await event.answer("Access Denied", alert=True)
        return

    inline = [
        [Button.inline(" TRIAL VMESS ","trial-vmess"), Button.inline(" CREATE VMESS ","create-vmess")],
        [Button.inline(" CHECK VMESS ","cek-vmess"), Button.inline(" DELETE VMESS ","delete-vmess")],
        [Button.inline(" 👥 SHOW ALL USER ","list-vmess")],
        [Button.inline("‹ Main Menu ›","menu")]
    ]
    
    try:
        z = requests.get(f"http://ip-api.com/json/?fields=country,isp").json()
        isp = z.get("isp", "Unknown")
        country = z.get("country", "Unknown")
    except:
        isp, country = "Unknown", "Unknown"

    msg = f"""
━━━━━━━━━━━━━━━━━━━━━━━ 
** HOKAGE PREMIUM TUNNELING **
━━━━━━━━━━━━━━━━━━━━━━━ 
 **⚠️ MENU VMESS / XRAY ⚠️**
━━━━━━━━━━━━━━━━━━━━━━━ 
🟢 **» Service:** `VMESS WS/GRPC`
🟢 **» Hostname:** `{DOMAIN}`
🟢 **» ISP:** `{isp}`
🟢 **» Country:** `{country}`
━━━━━━━━━━━━━━━━━━━━━━━ 
"""
    await event.edit(msg, buttons=inline)